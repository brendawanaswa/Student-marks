/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    char name[50];
    float marks;
    //Taking input from the user
    
    printf("Enter student name: ");
    fgets(name, sizeof(name), stdin);
    
    printf("Enter student marks: ");
    scanf("%f", &marks);
    
    //Displaying the details
    printf("\nStudent Details:\n");
    printf("Name: %s", name);
    printf("Marks: %.2f\n", marks);
    

    return 0;
}